import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset.csv")
print(df.head(10))
print(df["Cuisines"])

print(df.isnull().sum())
df["Cuisines"] = df["Cuisines"].fillna("NA")
print(df.isnull().sum())

top_3_cuisines = df["Cuisines"].value_counts().head(3)
print("*** Top 3 Cuisines ***")
print(top_3_cuisines)

percentage = df["Cuisines"].value_counts(normalize=True).mul(100).reset_index()
percentage.columns = ["Cuisines","Percentage"]
print(percentage)

df.to_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update.csv")
print("Filed Saved Successfully..")