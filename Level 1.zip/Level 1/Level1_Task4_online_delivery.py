import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update.csv")
print(df.head(10))
print(df.columns)

percentage = df["Has Online delivery"].value_counts(normalize=True).mul(100).reset_index()
percentage.columns = ["Has Online delivery","Percentage"]

print(percentage)

avg_rating = df.groupby("Has Online delivery")["Aggregate rating"].mean().sort_values(ascending=True)
print(avg_rating)
