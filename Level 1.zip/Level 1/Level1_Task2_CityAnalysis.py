import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update.csv")
print(df.head(5))

print(df.isnull().sum())
print(df["City"])

top_city = df["City"].value_counts().idxmax()
print(top_city)

restaurant_count = df["City"].value_counts().max()
print(restaurant_count)

print(f"The City With the Most Restaurant is {top_city} With {restaurant_count} Counts")

avg_rating = df.groupby("City")["Aggregate rating"].mean().sort_values(ascending=True)
print(avg_rating)

city_avg = df.groupby("City")["Aggregate rating"].mean()
print(city_avg)

top_city = city_avg.idxmax()
print(top_city)

highest_rating = city_avg.max()
print(highest_rating)

print(f"The City With Highest Average Rating is {top_city} with the average rating of {highest_rating}")