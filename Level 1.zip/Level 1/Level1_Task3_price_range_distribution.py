import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update.csv")
print(df.head(5))
print(df.columns)

print(df["Price range"])

price_range = df["Price range"].value_counts()
print(price_range)

# Bar Chart
price_range.plot(kind="bar")
plt.title("Bar Chart")
plt.xlabel("Price of Ranges")
plt.ylabel("Number of Restaurant")
plt.show()

percentage = df["Price range"].value_counts(normalize=True).mul(100).reset_index()
percentage.columns = ["Price range","Percentage"]

print(percentage)

