from collections import Counter
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update1.csv")
print(df.head(5))
print(df.columns)

print(df["Rating text"])

print("Rating Text Distribution")
print(df["Rating text"].value_counts())

positive = ["Good", "Very Good","Excellent"]
negative = ["Poor"]
neutral = ["Average","Not rated"]

sentiment_count = {
    "Positive" : df["Rating text"].isin(positive).sum(),
    "Negative" : df["Rating text"].isin(negative).sum(),
    "Neutral" : df["Rating text"].isin(neutral).sum()
}

print("\n --- Sentiment Counts ---")
for key,value in sentiment_count.items():
    print(f"{key}  =  {value}")
    
rating_word = Counter(df["Rating text"])
print("\n --- Most Common Rating Keyword --- ")
for keyword,count in rating_word.items():
    print(f"{keyword} = {count}")
    
df["Review_length"] = df["Rating text"].astype(str).apply(len)
avg_length = df["Review_length"].mean()

print(f"\nAverage length of Rating Text : {avg_length:.2f} character")

correlation = df["Review_length"].corr(df["Aggregate rating"])
print(f"Correlation between Rating Text Length and Aggregate rating : {correlation:.3f}")


plt.figure(figsize=(8,5))
plt.scatter(df["Review_length"],df["Aggregate rating"],alpha=0.5)
plt.title("Rating Text Length vs Aggregate Rating")
plt.xlabel("Rating Text Length")
plt.ylabel("Aggregate Rating")
plt.grid(True)
plt.show()


plt.figure(figsize=(6,4))
plt.bar(sentiment_count.keys(),sentiment_count.values())
plt.title("Sentiment Distribution")
plt.xlabel("Sentiment")
plt.ylabel("Count")
plt.show()

df.to_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update2.csv")
print("File Saved Successful..")