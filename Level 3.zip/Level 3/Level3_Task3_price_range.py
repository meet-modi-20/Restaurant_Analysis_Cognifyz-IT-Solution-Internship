import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update2.csv")
print(df.head())

print(df["Price range"])

online_delivery = pd.crosstab(df["Price range"],df["Has Online delivery"],normalize="index")*100


print("Online Delivery Percentage by Price Range : ")
print(online_delivery)

table_booking = pd.crosstab(df["Price range"],df["Has Table booking"],normalize="index")*100

print("Table booking Percentage by Price Range : ")
print(table_booking)


online_delivery["Yes"].plot(kind="bar")
plt.title("Price Range vs Online Delivery")
plt.ylabel("Percentage of Restaurant")
plt.show()


table_booking["Yes"].plot(kind="bar")
plt.title("Price Range vs Table Booking")
plt.ylabel("Percentage of Restaurant")
plt.show()
