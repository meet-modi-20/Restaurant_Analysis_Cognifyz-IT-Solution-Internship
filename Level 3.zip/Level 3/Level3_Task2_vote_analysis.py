import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update2.csv")
print(df.head(5))
print(df.describe())

print(df["Votes"])

highest_votes = df.loc[df["Votes"].idxmax()]
print(highest_votes)

print("\n\n ---- Restaurant Names With Highest Votes ----")
print("--------------------------------------------------")
print("\nRestaurant Names : ",highest_votes["Restaurant Name"])
print("City : ",highest_votes["City"])
print("Votes : ",highest_votes["Votes"])
print("Rating : ",highest_votes["Aggregate rating"])


lowest_votes = df.loc[df["Votes"].idxmin()]
print(lowest_votes)


print("\n\n ---- Restaurant Names With Lowest Votes ----")
print("--------------------------------------------------")
print("\nRestaurant Names : ",lowest_votes["Restaurant Name"])
print("City : ",lowest_votes["City"])
print("Votes : ",lowest_votes["Votes"])
print("Rating : ",lowest_votes["Aggregate rating"])



correlation = df["Review_length"].corr(df["Votes"])
print(f"Correlation between Rating Text Length and Aggregate rating : {correlation:.3f}")