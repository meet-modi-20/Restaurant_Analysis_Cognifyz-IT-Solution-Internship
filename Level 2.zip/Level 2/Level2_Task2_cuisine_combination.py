import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update1.csv")
print(df.head(5))
print(df.columns)

common_cuisine = df["Cuisines"].value_counts()
print(" ---- Most Common Combination Cuisines ---- ")
print(common_cuisine.head(10))

cuisine_high_rating = df.groupby("Cuisines")["Aggregate rating"].mean().sort_values(ascending=False)
print(" ---- Top 10 Highest Rating Cuisines ----")
print(cuisine_high_rating.head())