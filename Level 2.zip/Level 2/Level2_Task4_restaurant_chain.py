import pandas as pd
import matplotlib.pyplot as ptl
import seaborn as sns

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update1.csv")
print(df.head(10))

restaurant_counts = df["Restaurant Name"].value_counts()
print(restaurant_counts)

chains = restaurant_counts[restaurant_counts>1]
print(chains)

print(f"Total Unique Restaurant Chains Identified : {len(chains)}")
print(" ---- Top 10 Restaurant by Numbers of Outlets ----")
print(chains.head(10))