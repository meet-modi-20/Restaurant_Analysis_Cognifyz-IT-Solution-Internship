import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update.csv")
print(df.head(10))

print(df.columns)


df["Aggregate rating"].plot(kind="hist")
plt.hist(df["Aggregate rating"], bins=10)
plt.title("Distribution of Aggregate Ratings")
plt.xlabel("Aggregate Ratings (0.0 - 0.5) ")
plt.ylabel("Number of Restaurants")
plt.show()

df["Rating Range"] = pd.cut(df["Aggregate rating"],bins=[0,1,2,3,4,5],labels=['0 to 1','1 to 2','2 to 3','3 to 4','4 to 5'])
most_common = df["Aggregate rating"].value_counts()
print(most_common)

print("Missing Rating Range Value")
print(df["Rating Range"].isnull().sum())

df["Rating Range"] = df["Rating Range"].cat.add_categories(["NA"])

df["Rating Range"] = df["Rating Range"].fillna("NA")
print(df["Rating Range"].isnull().sum())

avg_votes = df["Votes"].mean()
print(f"Average Number of Votes Received by Restaurant : {avg_votes:.2f}")

df.to_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update1.csv")
print("File Saved Successful")
