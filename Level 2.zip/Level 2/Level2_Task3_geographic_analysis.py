import pandas as pd
import folium as fm # pyright: ignore
from folium.plugins import MarkerCluster # pyright: ignore

df = pd.read_csv("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\Dataset_update1.csv")

m = fm.Map(location=[df["Latitude"].mean(),df["Longitude"].mean()] ,zoom_start = 5)

marker_cluster = MarkerCluster().add_to(m)
print(marker_cluster)

for _, row in df.iterrows():fm.CircleMarker(location=[row["Latitude"], row["Longitude"]],radius=2,fill=True).add_to(m)

city_counts = df['City'].value_counts()

print(city_counts.head(10))

m.save("C:\\Users\\Meet Modi\\OneDrive\\Desktop\\Cognifyz IT Solution Internship\\restaurant_map.html")

print("Map saved as restaurant_map.html")
